README.txt
==========

Example_SARS-CoV-2_Japan_20210101_20210318.zip
----------------------------------------------

This file contains result and input files of TCS analysis using Japanese SARS-CoV-2 sequences from January to March 2021. COVID-19 cases in Japan are colored with red, and cases found in other situations in Japan are colored with cyan.

- input.SNV.fasta: input sequences for TCS.
- Figures.pdf: annotated result of the haplotype network.
- HX.txt: output file from Haplotype Explorer which can be input for HX.
- result.html: output file from Haplotype Explorer which visuallize the TCS network.

Contact
---------------------
Tetsuro Kawano-Sugaya
tks_jp@seikai.org